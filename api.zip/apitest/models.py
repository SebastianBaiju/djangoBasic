from django.db import models

class Employees(models.Model) :
    name = models.CharField(
        max_length=50,
    )
class Department(models.Model) :
    name = models.CharField(
        max_length=50,
    )
